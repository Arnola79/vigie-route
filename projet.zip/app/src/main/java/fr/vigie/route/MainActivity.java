package fr.vigie.route;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    static volatile WebView sWeb;
    private static final int REQ = 7;
    private static final String HOST = "vigie.local";
    private Sound sound;
    private boolean askedBattery = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        WebView web = new WebView(this);
        web.setBackgroundColor(0xFF0C1722);
        setContentView(web);
        sWeb = web;
        sound = new Sound(this);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        web.addJavascriptInterface(new Bridge(), "VigieNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String path = u.getPath();
                if (path == null || path.equals("/")) path = "/index.html";
                try {
                    InputStream in;
                    if (path.equals("/index.html")) in = indexStream();
                    else in = getAssets().open(path.substring(1));
                    return new WebResourceResponse(path.endsWith(".html") ? "text/html" : "application/octet-stream", "utf-8", in);
                } catch (IOException e) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, null);
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !HOST.equals(r.getUrl().getHost());
            }
        });
        web.loadUrl("https://" + HOST + "/index.html");
        askPermissions();
        checkUpdate(false);
    }

    // ---------- mise à jour automatique de l'interface ----------
    private File cachedFile() { return new File(getFilesDir(), "index.html"); }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        in.close();
        return o.toByteArray();
    }

    private static int ver(String html) {
        Matcher m = Pattern.compile("route[^v<]{0,12}v(\\d+)").matcher(html);
        return m.find() ? Integer.parseInt(m.group(1)) : 0;
    }

    private int assetVer() {
        try { return ver(new String(readAll(getAssets().open("index.html")), "UTF-8")); } catch (Exception e) { return 0; }
    }

    private int cachedVer() {
        try {
            File f = cachedFile();
            if (!f.exists()) return 0;
            return ver(new String(readAll(new java.io.FileInputStream(f)), "UTF-8"));
        } catch (Exception e) { return 0; }
    }

    /** Sert la version téléchargée si elle est plus récente que celle embarquée dans l'APK. */
    private InputStream indexStream() throws IOException {
        if (cachedFile().exists() && cachedVer() > assetVer()) return new java.io.FileInputStream(cachedFile());
        return getAssets().open("index.html");
    }

    private void checkUpdate(final boolean force) {
        final android.content.SharedPreferences sp = getSharedPreferences("upd", MODE_PRIVATE);
        final long now = System.currentTimeMillis();
        if (!force && now - sp.getLong("t", 0) < 6L * 3600 * 1000) return;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String url = new String(readAll(getAssets().open("update_url.txt")), "UTF-8").trim();
                    if (!url.startsWith("https://") || url.contains("OWNER")) {
                        if (force) js("window.__notice&&window.__notice('Adresse de mise à jour non configurée.')");
                        return;
                    }
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(20000);
                    c.setUseCaches(false);
                    if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode());
                    String body = new String(readAll(c.getInputStream()), "UTF-8");
                    sp.edit().putLong("t", now).apply();
                    if (body.length() < 20000 || !body.contains("<script>") || !body.contains("Vigie")) throw new IOException("fichier invalide");
                    int rv = ver(body), cur = Math.max(assetVer(), cachedVer());
                    if (rv > cur) {
                        File tmp = new File(getFilesDir(), "index.tmp");
                        FileOutputStream o = new FileOutputStream(tmp);
                        o.write(body.getBytes("UTF-8"));
                        o.close();
                        File dst = cachedFile();
                        if (dst.exists()) dst.delete();
                        if (!tmp.renameTo(dst)) throw new IOException("écriture impossible");
                        js("window.__notice&&window.__notice('Mise à jour v" + rv + " téléchargée.');window.__applyUpdate&&window.__applyUpdate()");
                    } else if (force) {
                        js("window.__notice&&window.__notice('Déjà à jour (v" + cur + ")');var e=document.getElementById('updInfo');if(e)e.textContent='À jour (v" + cur + ")'");
                    }
                } catch (Exception e) {
                    if (force) js("window.__notice&&window.__notice('Mise à jour impossible : " + String.valueOf(e.getMessage()).replace("'", " ").replace("\n", " ") + "')");
                }
            }
        }).start();
    }

    private void askPermissions() {
        java.util.ArrayList<String> need = new java.util.ArrayList<String>();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.ACCESS_FINE_LOCATION);
            need.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ);
        else askBattery();
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        askBattery();
        js("window.__autoPre&&window.__autoPre()");
    }

    /** Demande l'exemption d'optimisation de batterie pour que le système ne coupe jamais l'application. */
    private void askBattery() {
        if (askedBattery) return;
        askedBattery = true;
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())));
            }
        } catch (Exception ignored) { }
    }

    private void js(final String code) {
        final WebView w = sWeb;
        if (w != null) w.post(new Runnable() { @Override public void run() { w.evaluateJavascript(code, null); } });
    }

    static void deliver(Location l) {
        String code = String.format(Locale.US,
                "window.__nativeFix&&window.__nativeFix(%.6f,%.6f,%.1f,%.2f,%.1f,%d)",
                l.getLatitude(), l.getLongitude(), l.hasAccuracy() ? l.getAccuracy() : 0f,
                l.hasSpeed() ? l.getSpeed() : -1f, l.hasBearing() ? l.getBearing() : -1f, l.getTime());
        post(code);
    }

    static void gpsError(int c) { post("window.__nativeGpsError&&window.__nativeGpsError(" + c + ")"); }

    private static void post(final String code) {
        final WebView w = sWeb;
        if (w != null) w.post(new Runnable() { @Override public void run() { w.evaluateJavascript(code, null); } });
    }

    @Override protected void onResume() {
        super.onResume();
        sWeb.onResume();
        sWeb.resumeTimers();
        js("window.__autoPre&&window.__autoPre()");
    }

    /** On ne met pas la page en pause : elle continue de traiter le GPS en arrière-plan. */
    @Override protected void onStop() {
        super.onStop();
        sWeb.onResume();
        sWeb.resumeTimers();
    }

    @Override public void onBackPressed() { moveTaskToBack(true); }

    @Override protected void onDestroy() {
        stopService(new Intent(this, GpsService.class));
        if (sound != null) sound.shutdown();
        WebView w = sWeb;
        sWeb = null;
        if (w != null) w.destroy();
        super.onDestroy();
    }

    public final class Bridge {
        @JavascriptInterface public void startGps() {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                gpsError(1);
                runOnUiThread(new Runnable() { @Override public void run() { askPermissions(); } });
                return;
            }
            startForegroundService(new Intent(MainActivity.this, GpsService.class));
        }
        @JavascriptInterface public void checkUpdate() { MainActivity.this.checkUpdate(true); }
        @JavascriptInterface public void stopGps() { stopService(new Intent(MainActivity.this, GpsService.class)); }
        @JavascriptInterface public void beep(int freq, int durMs, int delayMs) { sound.beep(freq, durMs, delayMs); }
        @JavascriptInterface public void speak(String text) { sound.speak(text); }
        @JavascriptInterface public void vibrate(String json) {
            try {
                JSONArray a = new JSONArray(json);
                long[] p = new long[a.length() + 1];
                for (int i = 0; i < a.length(); i++) p[i + 1] = Math.max(0, a.optLong(i));
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                v.vibrate(VibrationEffect.createWaveform(p, -1));
            } catch (Exception ignored) { }
        }
        @JavascriptInterface public void keepScreen(final boolean on) {
            runOnUiThread(new Runnable() { @Override public void run() {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            } });
        }
        @JavascriptInterface public String lastLocation() {
            try {
                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                Location best = null;
                for (String p : lm.getProviders(true)) {
                    Location l = lm.getLastKnownLocation(p);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                }
                return best == null ? "" : String.format(Locale.US, "%.5f,%.5f", best.getLatitude(), best.getLongitude());
            } catch (Exception e) { return ""; }
        }
    }
}
