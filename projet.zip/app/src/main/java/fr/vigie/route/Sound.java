package fr.vigie.route;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.Locale;

/** Sons et voix d'alerte : l'audio demande le focus « ducking » pour baisser la musique. */
final class Sound {
    private final Context ctx;
    private final AudioManager am;
    private final AudioAttributes attrs = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();
    private final AudioFocusRequest focus;
    private final Handler main = new Handler(Looper.getMainLooper());
    private int users = 0;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private int uid = 0;

    Sound(Context c) {
        ctx = c.getApplicationContext();
        am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setWillPauseWhenDucked(false)
                .setOnAudioFocusChangeListener(new AudioManager.OnAudioFocusChangeListener() {
                    @Override public void onAudioFocusChange(int change) { }
                })
                .build();
        try {
            tts = new TextToSpeech(ctx, new TextToSpeech.OnInitListener() {
                @Override public void onInit(int status) {
                    if (status != TextToSpeech.SUCCESS || tts == null) return;
                    try {
                        int r = tts.setLanguage(Locale.FRANCE);
                        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                            tts.setLanguage(Locale.FRENCH);
                        }
                        tts.setAudioAttributes(attrs);
                        tts.setSpeechRate(1.05f);
                        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                            @Override public void onStart(String id) { }
                            @Override public void onDone(String id) { release(); }
                            @Override public void onError(String id) { release(); }
                        });
                        ttsReady = true;
                    } catch (Exception ignored) { }
                }
            });
        } catch (Exception ignored) { }
    }

    private synchronized void acquire() {
        if (users++ == 0) am.requestAudioFocus(focus);
    }

    private synchronized void release() {
        if (users > 0 && --users == 0) am.abandonAudioFocus(focus);
    }

    void speak(final String text) {
        if (!ttsReady || text == null || text.isEmpty()) return;
        main.post(new Runnable() {
            @Override public void run() {
                try {
                    acquire();
                    int r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "v" + (uid++));
                    if (r != TextToSpeech.SUCCESS) release();
                } catch (Exception e) { release(); }
            }
        });
    }

    void beep(final int freq, final int durMs, final int delayMs) {
        main.postDelayed(new Runnable() {
            @Override public void run() {
                new Thread(new Runnable() {
                    @Override public void run() { play(freq, Math.max(40, Math.min(durMs, 2000))); }
                }).start();
            }
        }, Math.max(0, delayMs));
    }

    private void play(int freq, int durMs) {
        final int rate = 22050;
        int n = rate * durMs / 1000;
        short[] pcm = new short[n];
        for (int i = 0; i < n; i++) {
            double env = Math.min(1.0, Math.min(i / (rate * 0.02), (n - i) / (rate * 0.03)));
            pcm[i] = (short) (Math.sin(2 * Math.PI * freq * i / rate) * env * 0.8 * Short.MAX_VALUE);
        }
        AudioTrack tr = null;
        acquire();
        try {
            tr = new AudioTrack.Builder()
                    .setAudioAttributes(attrs)
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build())
                    .setBufferSizeInBytes(n * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build();
            tr.write(pcm, 0, n);
            tr.play();
            Thread.sleep(durMs + 80);
        } catch (Exception ignored) {
        } finally {
            if (tr != null) { try { tr.stop(); } catch (Exception ignored) { } tr.release(); }
            release();
        }
    }

    void shutdown() {
        try { if (tts != null) { tts.stop(); tts.shutdown(); } } catch (Exception ignored) { }
        tts = null;
    }
}
