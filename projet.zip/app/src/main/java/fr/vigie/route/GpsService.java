package fr.vigie.route;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/** Service de premier plan : garde le GPS actif et le processus en vie, écran verrouillé ou application masquée. */
public class GpsService extends Service implements LocationListener {
    private static final String CHANNEL = "vigie_gps";
    private LocationManager lm;
    private PowerManager.WakeLock lock;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Trajet en cours", NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Vigie Route")
                .setContentText("Trajet en cours : GPS et alertes actifs")
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(1, n);
        }
        if (lock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "vigie:gps");
            lock.acquire(12 * 60 * 60 * 1000L);
        }
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            lm.removeUpdates(this);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
        } catch (SecurityException e) {
            MainActivity.gpsError(1);
            stopSelf();
        } catch (IllegalArgumentException e) {
            MainActivity.gpsError(2);
        }
        return START_NOT_STICKY;
    }

    @Override public void onLocationChanged(Location l) { MainActivity.deliver(l); }
    public void onProviderEnabled(String p) { }
    public void onProviderDisabled(String p) { MainActivity.gpsError(2); }
    public void onStatusChanged(String p, int s, Bundle e) { }

    @Override public void onDestroy() {
        try { if (lm != null) lm.removeUpdates(this); } catch (SecurityException ignored) { }
        if (lock != null && lock.isHeld()) lock.release();
        lock = null;
        super.onDestroy();
    }
}
